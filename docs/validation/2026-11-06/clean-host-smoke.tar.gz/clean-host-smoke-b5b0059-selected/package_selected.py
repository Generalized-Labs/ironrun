"""Select read-only clean-candidate smoke evidence; exclude raw prompts/stores."""
from pathlib import Path
import datetime,hashlib,json,re,shutil,subprocess,tarfile
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'selected';OUT.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,x):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def copy(src,name):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,p)
for n in ['run_clean_host_smoke.py','source-and-driver.json','host-tools.json','archive-binary-identity.json','ironrun-go-build-info.txt','package_selected.py','README-selected.md']:
 copy(ROOT/n,'README.md'if n=='README-selected.md'else n)
meta=json.loads((ROOT/'source-and-driver.json').read_text());identity=json.loads((ROOT/'archive-binary-identity.json').read_text())
assert sha(ROOT/'run_clean_host_smoke.py')==meta['driver_sha256']
assert sha(ROOT/'ironrun-linux-amd64')==identity['binary_sha256']
archive=Path(identity['archive_path']);assert sha(archive)==identity['archive_sha256_before']
with tarfile.open(archive,'r:gz')as t:
 assert hashlib.sha256(t.extractfile('ironrun').read()).hexdigest()==identity['binary_sha256']
version=subprocess.run([str(ROOT/'ironrun-linux-amd64'),'version','--verbose'],capture_output=True,text=True);assert version.returncode==0
(OUT/'ironrun-version.stdout.txt').write_text(version.stdout)
record=[]
for name in ['claude-approve','opencode-approve']:
 p=ROOT/name;s=json.loads((p/'summary.json').read_text())
 assert s['result']=='passed'and s['scenario']=='approve'and s['returncode']==0 and not s['timed_out']
 assert len(s['loopback'])==1 and s['loopback'][0]['credential_matches']and s['grant']['no_call_during_100ms_pending']
 assert s['ironrun_sha256']==identity['binary_sha256']
 assert any(x['tool_result_received']and x['result_redacted']and x['result_success_count']==1 for x in s['provider_observations'])
 assert all(x['full_synthetic_value_present']is False for x in s['provider_observations'])
 for n in ['summary.json','trust-grant.stdout.txt','trust-grant.stderr.txt']:
  copy(p/n,'cases/'+name+'/'+n)
 events=[]
 for line in (p/'host.stdout.txt').read_text().splitlines():
  try:x=json.loads(line)
  except json.JSONDecodeError:continue
  if x.get('type')=='assistant':
   for c in x.get('message',{}).get('content',[]):
    if c.get('type')=='tool_use'and c.get('name','').endswith('run_sealed'):events.append({'kind':'tool_call','name':c['name'],'input':c['input'],'id':c['id']})
  elif x.get('type')=='user':
   for c in x.get('message',{}).get('content',[]):
    if c.get('type')=='tool_result':
     content=c.get('content');assert'exit_code:'in json.dumps(content)
     events.append({'kind':'tool_result','id':c.get('tool_use_id'),'is_error':c.get('is_error',False),'ironrun_content':content})
  elif x.get('type')=='tool_use':
   c=x.get('part',{});state=c.get('state',{})
   if c.get('tool')=='ironrun_run_sealed':events.append({'kind':'tool_result','name':c['tool'],'id':c.get('callID'),'status':state.get('status'),'input':state.get('input'),'ironrun_content':state.get('output')})
 assert any(y['kind']=='tool_result'and'[REDACTED]'in json.dumps(y)for y in events)
 write('cases/'+name+'/selected-host-events.json',events)
 record.append({'case':name,'summary_sha256':sha(p/'summary.json'),'raw_file_inventory':[{'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f),'raw_selected':False}for f in sorted(p.glob('*.txt'))]})
write('case-inventory.json',record)
previous=Path('/workspace/ironrun-product-research/launch-20261105/hosts/claude-opencode/selected/provenance')
for n in ['tool-provenance.json','package-provenance.json','debian-metadata-provenance.json']:
 copy(previous/n,'provenance/'+n)
write('provenance/native-and-probe-executables.json',{k:v for k,v in json.loads((previous/'executables.json').read_text()).items()if k in['workspaceprobe','gnome-keyring-daemon','secret-tool']})
checks={}
for name,pattern in {'native_daemon':'^/workspace/ironrun-product-tools/native-linux/extracted/usr/bin/gnome-keyring-daemon --foreground','fixture_mcp':'^/workspace/ironrun-product-research/launch-20261106/clean-host-smoke/ironrun-linux-amd64 mcp --policy','fixture_driver':'^python3 /workspace/ironrun-product-research/launch-20261106/clean-host-smoke/run_clean_host_smoke.py'}.items():
 p=subprocess.run(['pgrep','-f',pattern],capture_output=True,text=True);checks[name]={'matching_processes':len(p.stdout.splitlines()),'pgrep_returncode':p.returncode}
assert all(x['matching_processes']==0 for x in checks.values())
write('completion-verification.json',{'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'driver_sha256_before':meta['driver_sha256'],'driver_sha256_after':sha(ROOT/'run_clean_host_smoke.py'),'binary_sha256_after':sha(ROOT/'ironrun-linux-amd64'),'archive_sha256_after_smoke':sha(archive),'archive_member_sha256_matches_tested_binary':True,'cleanup':checks,'passed_cases':2,'scope':'Approval/resume only; native Linux Secret Service; scripted local providers; unsigned diagnostic artifact.'})
manifest=[]
for p in sorted(OUT.rglob('*')):
 if p.is_file()and p.name!='artifact-manifest.json':
  b=p.read_bytes();assert not re.search(rb'test-only-host-fixture-[a-f0-9]{48}',b),p
  n=str(p.relative_to(OUT));assert not re.search(r'(^|/)(home|cache|keyrings|vault|tools)(/|$)',n),n
  manifest.append({'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
write('artifact-manifest.json',manifest)
for x in manifest:assert sha(OUT/x['path'])==x['sha256']
a=ROOT/'clean-host-smoke-b5b0059-selected.tar.gz'
with tarfile.open(a,'w:gz')as t:t.add(OUT,arcname='clean-host-smoke-b5b0059-selected')
info={'artifact':a.name,'bytes':a.stat().st_size,'sha256':sha(a),'manifest_sha256':sha(OUT/'artifact-manifest.json'),'selected_file_count':len(manifest),'passed_cases':2,'binary_sha256':identity['binary_sha256'],'source_commit':identity['commit']}
(ROOT/'selected-archive.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info))
