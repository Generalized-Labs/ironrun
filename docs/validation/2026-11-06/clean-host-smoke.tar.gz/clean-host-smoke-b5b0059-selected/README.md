# Clean diagnostic artifact: Linux host approval/resume smoke

Actual Claude Code 2.1.318 and OpenCode 1.19.5 each passed one fresh approval/resume integration fixture using the clean `b5b0059fc088745296999ad84f5b0726a631f85f` Linux amd64 diagnostic artifact and native GNOME Secret Service. This set contains two approval/resume cases. It does not repeat or inherit the older diagnostic binary's lifecycle matrix.

## Artifact identity

The tested file was extracted into a separate private fixture directory from the completed `ironrun_Linux_x86_64.tar.gz` archive. Only a strict regular `ironrun` member was written. No release output, prior evidence or repository source was modified.

- Source commit: `b5b0059fc088745296999ad84f5b0726a631f85f`.
- Source tree: `ff248424f675a9f41969afe6ebec74c3cdf34185`.
- Reported version: `0.5.1-rc.1-diagnostic`; build timestamp `2026-11-06T00:20:57Z`.
- Tested/archive-member binary SHA256: `1f5457786ccdc5aab009a143841486f28bc809d5c8b843bab2d30e68926d4ad0`.
- Source archive SHA256: `f6f3587ae42706dbd6ef70a10b99bf08cac974ad5ccb68a5e709e568b7a9fa83`.
- New driver SHA256: `b5d4ebac103bf499d654b4990ed6ecb37082dcbbbb3f30db4c38af3c1944be23`.

`archive-binary-identity.json` records extraction identity; `completion-verification.json` rechecks archive, member, tested binary and unchanged driver after both runs. This is an unsigned diagnostic snapshot, not a claim of signed artifact verification or final release readiness. The release worker's final archive/SBOM checks remain separate.

`source-and-driver.json` records all 182 Go/module input hashes from the fixed source commit and the exact prior/new driver hashes. The driver differs from preserved `run_host_v6.py` only in its host-tool root path and Ironrun binary path; fresh output paths are invocation arguments. Original host version output and case timestamps are retained without rewriting.

## Observed path

| Host | Result | Actual platform store | Provider |
|---|---|---|---|
| Claude Code 2.1.318 | Approval/resume passed | Native Linux Secret Service | Scripted local Anthropic-compatible SSE |
| OpenCode 1.19.5 | Approval/resume passed | Native Linux Secret Service | Scripted local chat-completions SSE |

Each run creates a fresh project, HOME/IRONRUN_HOME/XDG directories, private DBus session and disposable native collection. Actual Ironrun CLI initializes an environment and stores a random test-only value from stdin. The actual host connects to the actual stdio MCP server and calls `run_sealed`. A persisted pending request is observed with no loopback call during a 100 ms window. The test controller approves through actual `ironrun trust grant`; the original waiting tool call resumes.

Exactly one local HTTP request carries the matching synthetic value. The child/endpoint print that value, but the actual host and its subsequent scripted provider request receive `credential=[REDACTED]` and `HOST_LOOPBACK [REDACTED]`. Neither provider requests nor captured host output contain the complete synthetic value. Host process exit is zero, and success requires these execution/redaction checks rather than the provider's final text alone.

`cases/*/summary.json` preserves tool discovery/provider observations, request IDs, actual CLI grants, timestamps and outcomes. `selected-host-events.json` retains only the relevant Ironrun calls/results. `case-inventory.json` records sizes and hashes of omitted raw logs. `host-tools.json` records fresh actual version output and binary hashes; provenance records retain npm integrity and native Debian verification identities.

## Limits

The provider supplies deterministic tool arguments; no real model judgment or provider account is tested. The controller supplies Ironrun approval; no human timing or interactive approval UX is measured. Each isolated host permits only the fixture's `run_sealed` tool. This setting tests the separate Ironrun approval boundary and does not validate default host permissions or recommend global autoapproval.

This set does not test denial, expiry, revocation, cancellation, pending-request expiry, sustained usage, host reconnect, real external services, macOS Keychain, Codex or Cursor. Older lifecycle evidence remains attached to its original binary identity. A finite 100 ms pending observation is not a universal timing or authorization proof. Instrumented local endpoints are observed; all background host traffic/system calls are not traced.

`completion-verification.json` reports no matching fixture native daemon, MCP server or driver left after execution. The compact package excludes downloaded binaries, the diagnostic binary, private homes, native keyrings/vaults, raw built-in host instructions, full provider bodies, caches and authentication state.

## Replay

Obtain the exact public host/native dependencies recorded in provenance, plus the archive with the recorded hash. Adapt only absolute paths in a new identified driver copy and extract the candidate binary into a separate directory. Run the driver with a fresh output HOME, for example:

```
python3 run_clean_host_smoke.py claude /absolute/new-claude-output approve
python3 run_clean_host_smoke.py opencode /absolute/new-opencode-output approve
```

Do not point the fixture at an existing host home or production vault. Managed proxy/TLS settings are inherited. Only local synthetic providers and disposable native collections are used. `package_selected.py` specifies compact evidence selection; `artifact-manifest.json` hashes every selected file except itself.
