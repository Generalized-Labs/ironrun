"""Select compact host evidence without homes, stores, raw prompts or binaries."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'selected'
OUT.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path,x):
 p=OUT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def copy(src,dst):
 p=OUT/dst;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,p)
for n in ['run_host.py','run_host_v2.py','run_host_v3.py','run_host_v4.py','run_host_v5.py','run_host_v6.py','tool-provenance.json','claude-version.stdout.txt','opencode-version.stdout.txt','claude-help.stdout.txt','claude-mcp-help.stdout.txt','opencode-help.stderr.txt','opencode-run-help.txt','opencode-mcp-help.stderr.txt']:
 copy(ROOT/n,Path('drivers'if n.endswith('.py')else'provenance')/n)
copy(Path(__file__).resolve(),'package_selected.py')
cases={
 'claude-approve-final':'run_host_v4.py','claude-deny-attempt2':'run_host_v4.py',
 'claude-expiry-attempt1':'run_host_v4.py','claude-revoke-attempt1':'run_host_v4.py','claude-cancel-final':'run_host_v6.py',
 'opencode-approve-final':'run_host_v4.py','opencode-deny-attempt1':'run_host_v4.py',
 'opencode-expiry-attempt1':'run_host_v4.py','opencode-revoke-attempt1':'run_host_v4.py','opencode-cancel-attempt1':'run_host_v4.py'}
retained={'claude-attempt1':'run_host.py','opencode-attempt1':'run_host.py','opencode-attempt2':'run_host_v2.py','claude-deny-attempt1':'run_host_v3.py','claude-cancel-attempt1':'run_host_v4.py','claude-cancel-attempt2':'run_host_v5.py'}
inventory=[]
for name,driver in {**retained,**cases}.items():
 folder=ROOT/name;final=name in cases
 rec={'case':name,'selected_final_case':final,'driver':driver,'driver_sha256':sha(ROOT/driver),'raw_file_inventory':[]}
 for p in sorted(folder.glob('*.txt')):
  rec['raw_file_inventory'].append({'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p),'raw_file_selected':False})
 if (folder/'summary.json').exists():
  summary=json.loads((folder/'summary.json').read_text());rec['result']=summary['result'];rec['scenario']=summary.get('scenario','approve')
  copy(folder/'summary.json',Path('cases'if final else'retained')/name/'summary.json')
 else:rec['result']='fixture-setup-failed';rec['scenario']='deny'
 safe=[]
 if (folder/'host.stdout.txt').exists():
  for line in (folder/'host.stdout.txt').read_text(errors='replace').splitlines():
   try:event=json.loads(line)
   except json.JSONDecodeError:continue
   if event.get('type')=='assistant':
    for c in event.get('message',{}).get('content',[]):
     if c.get('type')=='tool_use'and c.get('name','').endswith('run_sealed'):
      safe.append({'kind':'tool_call','name':c['name'],'input':c['input'],'id':c['id']})
   if event.get('type')=='user':
    for c in event.get('message',{}).get('content',[]):
     if c.get('type')=='tool_result':
      text=c.get('content');encoded=json.dumps(text)
      q={'kind':'tool_result','id':c.get('tool_use_id'),'is_error':c.get('is_error',False),'content_sha256':hashlib.sha256(encoded.encode()).hexdigest()}
      if 'exit_code:'in encoded or 'trusted workspace request'in encoded or 'workspace run cancelled'in encoded:q['ironrun_content']=text
      else:q['host_interrupt_or_rejection_content_omitted']=True
      safe.append(q)
     elif c.get('type')=='text'and'[Request interrupted by user'in c.get('text',''):safe.append({'kind':'host_interrupted_message','observed':True})
   if event.get('type')=='result':safe.append({'kind':'host_completion',**{k:event[k]for k in ['subtype','is_error','terminal_reason']if k in event}})
   if event.get('type')=='tool_use':
    part=event.get('part',{});state=part.get('state',{})
    if part.get('tool')=='ironrun_run_sealed':safe.append({'kind':'tool_result','name':part['tool'],'id':part.get('callID'),'status':state.get('status'),'input':state.get('input'),'ironrun_content':state.get('output')})
 if safe:write(Path('cases'if final else'retained')/name/'selected-host-events.json',safe)
 for n in ['trust-grant','trust-revoke','trust-expired-status','access-deny-1','access-deny-2']:
  for suffix in ['stdout.txt','stderr.txt']:
   f=folder/(n+'.'+suffix)
   if f.exists():copy(f,Path('cases'if final else'retained')/name/f.name)
 inventory.append(rec)
write(Path('case-inventory.json'),inventory)
# Bind exactly the previously compiled diagnostic binary. Do not relabel it a tagged artifact.
native=Path('/workspace/ironrun-product-research/launch-20261030/native-linux')
copy(native/'source-identity.json',Path('provenance/original-runtime-source-identity.json'))
for f in ['package-provenance.json','debian-metadata-provenance.json']:
 copy(native/f,Path('provenance')/f)
source=json.loads((native/'source-identity.json').read_text());target='829099e4bb46247dc7abd324f18e870b6eb2cd9f'
mismatches=[]
for n,h in source['files'].items():
 p=subprocess.run(['git','show',target+':'+n],cwd='/workspace/ironrun',capture_output=True)
 if p.returncode or hashlib.sha256(p.stdout).hexdigest()!=h:mismatches.append(n)
assert not mismatches
write(Path('provenance/source-comparison.json'),{'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'comparison_commit':target,'file_count':len(source['files']),'mismatches':mismatches,'claim':'All recorded 182 Go/module inputs of diagnostic binary match this fixed commit. Later module normalization/release builds require their own evidence.'})
paths={'ironrun':native/'ironrun','workspaceprobe':native/'workspaceprobe','claude':ROOT/'tools/claude-code-linux-x64/package/claude','opencode':ROOT/'tools/opencode-linux-x64/package/bin/opencode','gnome-keyring-daemon':Path('/workspace/ironrun-product-tools/native-linux/extracted/usr/bin/gnome-keyring-daemon'),'secret-tool':Path('/workspace/ironrun-product-tools/native-linux/extracted/usr/bin/secret-tool')}
write(Path('provenance/executables.json'),{n:{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}for n,p in paths.items()})
p=subprocess.run(['/workspace/ironrun-product-tools/go/bin/go','version','-m',str(native/'ironrun')],capture_output=True,text=True)
assert p.returncode==0
(OUT/'provenance/ironrun-go-build-info.txt').write_text(p.stdout)
# Cursor gate records: omit response cookies and do not bypass the vendor's rejection.
cursor=ROOT.parent/'cursor'
for n in ['gui-prerequisites.json','official-download-metadata.json','vendor-package-access-recheck.json']:
 copy(cursor/n,Path('cursor')/n)
old=json.loads((cursor/'vendor-package-access.json').read_text());old['headers']={k:v for k,v in old['headers'].items()if k.lower()!='set-cookie'}
write(Path('cursor/vendor-package-access-original-safe.json'),old)
checks={
 'native_daemon':'^/workspace/ironrun-product-tools/native-linux/extracted/usr/bin/gnome-keyring-daemon --foreground',
 'fixture_mcp':'^/workspace/ironrun-product-research/launch-20261030/native-linux/ironrun mcp --policy /workspace/ironrun-product-research/launch-20261105/hosts/claude-opencode/',
 'fixture_driver':'^python3 /workspace/ironrun-product-research/launch-20261105/hosts/claude-opencode/run_host'}
cleanup={}
for n,pattern in checks.items():
 p=subprocess.run(['pgrep','-f',pattern],capture_output=True,text=True)
 cleanup[n]={'matching_processes':len(p.stdout.splitlines()),'pgrep_returncode':p.returncode}
assert all(x['matching_processes']==0 for x in cleanup.values()),cleanup
write(Path('provenance/cleanup.json'),{'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':cleanup,'scope':'Fixture paths/process names only; unrelated user processes and stores are not inspected.'})
# The prior Codex pass used an adapter, and must not acquire the new native-store claim.
codex=Path('/workspace/ironrun-product-research/launch-20261026/codex-host/selected-final-copy')
copy(codex/'README.md',Path('prior-codex/README.md'))
copy(codex/'final/summary.json',Path('prior-codex/summary.json'))
write(Path('matrix.json'),{'claude':{'version':'2.1.318','platform':'Linux amd64','backend':'native Secret Service','cases':{json.loads((ROOT/k/'summary.json').read_text())['scenario']:k for k in cases if k.startswith('claude')}},'opencode':{'version':'1.19.5','platform':'Linux amd64','backend':'native Secret Service','cases':{json.loads((ROOT/k/'summary.json').read_text())['scenario']:k for k in cases if k.startswith('opencode')}},'codex':{'version':'0.159.2','scope':'Earlier approve/resume scripted-provider pass with synthetic native-store adapter; lifecycle/native backend not newly tested here.','evidence':'prior-codex/README.md'},'cursor':{'result':'blocked','scope':'No host execution; official 3.28.7 Linux package denied HTTP403/Cloudflare1010. Fixture lacks running GUI and authorized Cursor session.','evidence':'cursor/vendor-package-access-recheck.json'}})
# No binary, home, keyring, vault, raw provider request or full raw host log is selected.
manifest=[]
for f in sorted(OUT.rglob('*')):
 if f.is_file()and f.name!='artifact-manifest.json':manifest.append({'path':str(f.relative_to(OUT)),'bytes':f.stat().st_size,'sha256':sha(f)})
write(Path('artifact-manifest.json'),manifest)
print(json.dumps({'selected_files':len(manifest),'bytes':sum(x['bytes']for x in manifest),'final_cases':len(cases),'retained_cases':len(retained),'cleanup':cleanup}))
