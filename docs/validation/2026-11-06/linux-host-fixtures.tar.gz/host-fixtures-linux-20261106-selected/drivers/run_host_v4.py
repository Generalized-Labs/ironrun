"""Actual installed host -> Ironrun MCP -> native store fixture.

The provider is a scripted loopback endpoint, not a real model or human pilot.
Every run uses a new HOME, native collection and project. No user auth is used.
"""
from pathlib import Path
import datetime,hashlib,http.server,json,os,secrets,signal,subprocess,sys,tempfile,threading,time

ROOT=Path(__file__).resolve().parent
NATIVE=Path('/workspace/ironrun-product-tools/native-linux/extracted')
IRONRUN=Path('/workspace/ironrun-product-research/launch-20261030/native-linux/ironrun')
PROBE=Path('/workspace/ironrun-product-research/launch-20261030/native-linux/workspaceprobe')
VALUE='test-only-host-fixture-'+secrets.token_hex(24)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

class Loopback(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        self.server.calls.append({'credential_matches':self.headers.get('X-Ironrun-Fixture')==VALUE,'monotonic_ns':time.monotonic_ns()})
        self.send_response(200);self.end_headers();self.wfile.write(('HOST_LOOPBACK '+VALUE+'\n').encode())

class Model(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_POST(self):
        body=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))))
        if self.path.endswith('/count_tokens'):
            self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(b'{"input_tokens": 10}');return
        tools=body.get('tools',[])
        names=[t.get('name') or t.get('function',{}).get('name')for t in tools]
        tool=next((n for n in names if n and n.endswith('run_sealed')),None)
        old=json.dumps(body.get('messages',[]))
        assert VALUE not in old, 'Provider received full synthetic value'
        results=[]
        for msg in body.get('messages',[]):
            if msg.get('role')=='tool':results.append(msg.get('content',''))
            elif isinstance(msg.get('content'),list):
                results.extend(c.get('content','')for c in msg['content']if isinstance(c,dict)and c.get('type')=='tool_result')
        result_text=json.dumps(results)
        called=bool(results)
        count=len(results)
        if self.server.scenario in ['expiry','revoke']and count==1 and not self.server.action_done:
            self.server.after_first_result();self.server.action_done=True
        
        record={'path':self.path,'tool_names':names,'selected_tool':tool,'tool_result_received':called,'full_synthetic_value_present':False,'tool_result_count':count,'result_success_count':result_text.count('exit_code: 0'),'result_redacted':bool(results)and'[REDACTED]'in result_text,'denied_result': 'was denied'in result_text}
        self.server.observed.append(record)
        call=bool(tool and(count==0 or(self.server.scenario in ['expiry','revoke']and count==1)))
        call_id='toolu_fixture'+str(count)if self.server.host=='claude'else'call_fixture'+str(count)
        if self.server.host=='claude':
            events=[('message_start',{'type':'message_start','message':{'id':'msg_fixture','type':'message','role':'assistant','model':body.get('model'),'content':[],'stop_reason':None,'stop_sequence':None,'usage':{'input_tokens':10,'output_tokens':1}}})]
            if call:
                events.extend([('content_block_start',{'type':'content_block_start','index':0,'content_block':{'type':'tool_use','id':call_id,'name':tool,'input':{}}}),('content_block_delta',{'type':'content_block_delta','index':0,'delta':{'type':'input_json_delta','partial_json':json.dumps({'argv':self.server.argv})}})])
            else:
                events.extend([('content_block_start',{'type':'content_block_start','index':0,'content_block':{'type':'text','text':''}}),('content_block_delta',{'type':'content_block_delta','index':0,'delta':{'type':'text_delta','text':'HOST_FIXTURE_DONE' if called else 'HOST_NO_TOOL'}})])
            events.extend([('content_block_stop',{'type':'content_block_stop','index':0}),('message_delta',{'type':'message_delta','delta':{'stop_reason':'tool_use'if call else'end_turn','stop_sequence':None},'usage':{'output_tokens':2}}),('message_stop',{'type':'message_stop'})])
            data=''.join('event: '+n+'\ndata: '+json.dumps(v)+'\n\n'for n,v in events).encode()
        else:
            delta={'role':'assistant','tool_calls':[{'index':0,'id':call_id,'type':'function','function':{'name':tool,'arguments':json.dumps({'argv':self.server.argv})}}]} if call else {'role':'assistant','content':'HOST_FIXTURE_DONE'if called else'HOST_NO_TOOL'}
            base={'id':'chatcmpl-fixture','object':'chat.completion.chunk','created':1,'model':body.get('model')}
            chunks=[{**base,'choices':[{'index':0,'delta':delta,'finish_reason':None}]},{**base,'choices':[{'index':0,'delta':{},'finish_reason':'tool_calls'if call else'stop'}],'usage':{'prompt_tokens':10,'completion_tokens':2,'total_tokens':12}}]
            data=(''.join('data: '+json.dumps(c)+'\n\n'for c in chunks)+'data: [DONE]\n\n').encode()
        self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)

def inner(host,out):
    scenario=sys.argv[3]if len(sys.argv)>3 and sys.argv[3]!='--inner'else'approve'
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    project=out/'project';project.mkdir()
    observations={};native=None;process=None
    def cli(label,args,data=None):
        p=subprocess.run([str(IRONRUN),*args],cwd=project,input=data,capture_output=True,timeout=20)
        assert VALUE.encode()not in p.stdout+p.stderr
        (out/(label+'.stdout.txt')).write_bytes(p.stdout);(out/(label+'.stderr.txt')).write_bytes(p.stderr)
        assert p.returncode==0,label+': '+str(p.returncode)
        return p
    native_out=(out/'native.stdout.txt').open('wb');native_err=(out/'native.stderr.txt').open('wb')
    native=subprocess.Popen([str(NATIVE/'usr/bin/gnome-keyring-daemon'),'--foreground','--components=secrets','--control-directory',str(Path(os.environ['XDG_RUNTIME_DIR'])/'keyring'),'--unlock'],stdin=subprocess.PIPE,stdout=native_out,stderr=native_err)
    native.stdin.write(b'test-only-disposable-host-keyring-password\n');native.stdin.close()
    for _ in range(100):
        p=subprocess.run(['gdbus','call','--session','--dest','org.freedesktop.DBus','--object-path','/org/freedesktop/DBus','--method','org.freedesktop.DBus.NameHasOwner','org.freedesktop.secrets'],capture_output=True)
        if b'true'in p.stdout:break
        assert native.poll()is None;time.sleep(.05)
    else:raise AssertionError('Native service absent')
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Loopback);server.calls=[]
    model=http.server.ThreadingHTTPServer(('127.0.0.1',0),Model);model.host=host;model.observed=[];model.scenario=scenario;model.action_done=False
    actions=[]
    def after_first_result():
        state=json.loads((project/'.ironrun/access.json').read_text());grants=state.get('workspace_grants',[])
        assert len(grants)==1,state.keys()
        grant_id=grants[0]['id']
        if scenario=='revoke':cli('trust-revoke',['trust','revoke',grant_id])
        else:time.sleep(1.2);cli('trust-expired-status',['trust','list'])
        actions.append({'kind':scenario,'grant_id':grant_id,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    model.after_first_result=after_first_result
    for x in [server,model]:threading.Thread(target=x.serve_forever,daemon=True).start()
    model.argv=[str(PROBE),'http',f'http://127.0.0.1:{server.server_port}/']
    policy=project/'ironrun.yml';policy.write_text('version: "2"\ncommands:\n  - id: fixture\n    argv: '+json.dumps(model.argv)+'\n    secrets: [IRONRUN_E2E_TOKEN]\n    allow_network: true\n    ttl: 10s\n')
    try:
        cli('env-init',['env','init','dev']);cli('env-set',['env','set','dev','IRONRUN_E2E_TOKEN','--from-stdin','--unsafe'],(VALUE+'\n').encode())
        mcp={'ironrun':{'command':str(IRONRUN),'args':['mcp','--policy',str(policy)]}}
        env={**os.environ,'CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC':'1','DISABLE_TELEMETRY':'1','ENABLE_TOOL_SEARCH':'false','ANTHROPIC_API_KEY':'synthetic-local-provider-only','ANTHROPIC_BASE_URL':f'http://127.0.0.1:{model.server_port}','CLAUDE_CONFIG_DIR':str(out/'home/claude'),'OPENCODE_DISABLE_MODELS_FETCH':'1'}
        if host=='claude':
            config=project/'mcp.json';config.write_text(json.dumps({'mcpServers':mcp}))
            args=[str(ROOT/'tools/claude-code-linux-x64/package/claude'),'--bare','--print','--model','claude-sonnet-4-5','--output-format','stream-json','--verbose','--no-session-persistence','--strict-mcp-config','--mcp-config',str(config),'--tools','','--allowedTools','mcp__ironrun__run_sealed','--system-prompt','This is a synthetic host integration fixture. Use only the requested Ironrun tool.','Call the Ironrun run_sealed tool with the exact argv supplied by the local fixture provider; then report its result.']
        else:
            config={'$schema':'https://opencode.ai/config.json','model':'fixture/test','provider':{'fixture':{'npm':'@ai-sdk/openai-compatible','name':'Local fixture','options':{'baseURL':f'http://127.0.0.1:{model.server_port}/v1','apiKey':'synthetic-local-provider-only'},'models':{'test':{'name':'Synthetic fixture','limit':{'context':200000,'output':2000}}}}},'mcp':{'ironrun':{'type':'local','command':[str(IRONRUN),'mcp','--policy',str(policy)],'enabled':True,'timeout':120000}},'permission':{'*':'deny','ironrun_run_sealed':'allow'}}
            (project/'opencode.json').write_text(json.dumps(config));args=[str(ROOT/'tools/opencode-linux-x64/package/bin/opencode'),'run','--dir',str(project),'--pure','--model','fixture/test','--format','json','Call only ironrun_run_sealed with the exact argv supplied by the local fixture provider.']
        stdout=(out/'host.stdout.txt').open('wb');stderr=(out/'host.stderr.txt').open('wb')
        process=subprocess.Popen(args,cwd=project,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        deadline=time.monotonic()+45;grant=None;handled=set();interrupted=False
        while process.poll()is None and time.monotonic()<deadline:
            try:
                state=json.loads((project/'.ironrun/access.json').read_text());pending=next((x for x in state.get('requests',[])if x.get('status')=='pending'and x.get('kind')=='workspace'and x['id']not in handled),None)
            except (FileNotFoundError,json.JSONDecodeError):pending=None
            if pending:
                handled.add(pending['id']);time.sleep(.1)
                expected_calls=1 if grant else 0
                assert len(server.calls)==expected_calls,'Loopback before approval'
                if scenario=='cancel':
                    os.killpg(process.pid,signal.SIGINT);interrupted=True
                    actions.append({'kind':'interrupt-pending-host-process-group','request_id':pending['id'],'loopback_count':len(server.calls)})
                elif scenario=='deny'or grant is not None:
                    cli('access-deny-'+str(len(handled)),['access','deny',pending['id']])
                    actions.append({'kind':'deny-pending','request_id':pending['id'],'loopback_count':len(server.calls)})
                else:
                    cli('trust-grant',['trust','grant',pending['id'],'--ttl','1s'if scenario=='expiry'else'1m']);grant={'request_id':pending['id'],'no_call_during_100ms_pending':True}
            time.sleep(.05)
        timed_out=process.poll()is None
        if timed_out:os.killpg(process.pid,signal.SIGTERM)
        process.wait(timeout=10);stdout.close();stderr.close()
        output=(out/'host.stdout.txt').read_text(errors='replace')+(out/'host.stderr.txt').read_text(errors='replace')
        assert VALUE not in output
        result_received=any(x['tool_result_received']for x in model.observed)
        denied=any(x['denied_result']for x in model.observed)
        if scenario=='cancel':passed=interrupted and not timed_out and process.returncode!=0 and not server.calls and grant is None
        elif scenario=='deny':passed=process.returncode==0 and denied and not server.calls and grant is None
        else:passed=process.returncode==0 and grant is not None and len(server.calls)==1 and all(x['credential_matches']for x in server.calls)and result_received and any(x['result_redacted']for x in model.observed)and(scenario=='approve'or(denied and model.action_done))
        result={'host':host,'scenario':scenario,'started_utc':started,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actions':actions,'result':'passed'if passed else'blocked-or-failed','returncode':process.returncode,'timed_out':timed_out,'grant':grant,'loopback':server.calls,'provider_observations':model.observed,'ironrun_sha256':sha(IRONRUN),'limits':['Actual host CLI, scripted local provider; not real model judgment/human usability.','Native Linux Secret Service; not Mac Keychain.','Host run_sealed tool explicitly allowed only in this isolated synthetic fixture.','Cancel means SIGINT of the isolated pending host process group, not proof of GUI/protocol cancellation.'],'stderr_excerpt':(out/'host.stderr.txt').read_text(errors='replace')[-1800:]}
        (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));return 0 if passed else 1
    finally:
        if process:
            try:os.killpg(process.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            if process.poll()is None:process.wait(timeout=10)
        native.terminate();native.wait(timeout=10);native_out.close();native_err.close()
        for x in [server,model]:x.shutdown();x.server_close()

def main():
    host=sys.argv[1];out=Path(sys.argv[2])
    if '--inner'in sys.argv:return inner(host,out)
    out.mkdir(parents=True,exist_ok=True);home=out/'home';assert not home.exists()
    for d in ['config','cache','data','state','runtime','runtime/keyring']:(home/d).mkdir(parents=True,exist_ok=True);(home/d).chmod(0o700)
    runtime=tempfile.TemporaryDirectory(prefix='ironrun-host-');(Path(runtime.name)/'keyring').mkdir(mode=0o700)
    env={**os.environ,'HOME':str(home),'IRONRUN_HOME':str(home/'ironrun'),'XDG_CONFIG_HOME':str(home/'config'),'XDG_CACHE_HOME':str(home/'cache'),'XDG_DATA_HOME':str(home/'data'),'XDG_STATE_HOME':str(home/'state'),'XDG_RUNTIME_DIR':runtime.name,'PATH':str(NATIVE/'usr/bin')+':/usr/local/bin:/usr/bin:/bin','LD_LIBRARY_PATH':str(NATIVE/'usr/lib/x86_64-linux-gnu')}
    for key in ['DBUS_SESSION_BUS_ADDRESS','GNOME_KEYRING_CONTROL','SSH_AUTH_SOCK','GPG_AGENT_INFO','DISPLAY','WAYLAND_DISPLAY']:env.pop(key,None)
    p=subprocess.run(['dbus-run-session','--',sys.executable,str(Path(__file__).resolve()),host,str(out),sys.argv[3]if len(sys.argv)>3 else'approve','--inner'],env=env,capture_output=True,text=True,timeout=100)
    runtime.cleanup();(out/'driver.stdout.txt').write_text(p.stdout);(out/'driver.stderr.txt').write_text(p.stderr);print(json.dumps({'host':host,'returncode':p.returncode,'stdout':p.stdout[-1500:],'stderr':p.stderr[-1500:]}));return p.returncode

if __name__=='__main__':raise SystemExit(main())
