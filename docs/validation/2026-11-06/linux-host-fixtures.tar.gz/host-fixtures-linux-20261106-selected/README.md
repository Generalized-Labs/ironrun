# Linux agent-host integration evidence

Actual Claude Code 2.1.318 and OpenCode 1.19.5 execute Ironrun through stdio MCP on Linux amd64 using a disposable native GNOME Secret Service collection. Each host passes five bounded, scripted-provider scenarios. This is integration evidence, not a human usability study, real-model evaluation, macOS pilot, or release-artifact qualification.

| Scenario | Claude Code | OpenCode | What was observed |
|---|---|---|---|
| Approval/resume | Pass | Pass | Pending request; no HTTP call during a 100 ms observation; actual CLI grant; original call resumes; exactly one matching synthetic HTTP credential; redacted result reaches next provider request. |
| Denial | Pass | Pass | Actual CLI denies pending request; host receives denied tool result; no grant or HTTP call. |
| Grant expiry | Pass | Pass | Grant with actual 1 s TTL permits first call; after 1.2 s, second call needs a fresh request and is denied; no second HTTP call. |
| Grant revocation | Pass | Pass | Actual CLI revokes grant after first call; second call needs a fresh request and is denied; no second HTTP call. |
| Pending process interruption | Pass, bounded | Pass, bounded | SIGINT sent to isolated host process group while awaiting approval; no grant or probe HTTP request was observed before host exit; no fixture deadline timeout. |

`matrix.json` identifies exact selected cases and host/backend versions. Case summaries preserve process exit codes, timestamps, provider observations and actual CLI actions. Selected host events contain only Ironrun call/result items and minimal host completion/interruption fields. Raw host logs, built-in instructions, provider request bodies, credential stores, caches and binaries are excluded.

## What ran

Every case uses a fresh HOME, IRONRUN_HOME, XDG configuration/data/state, project, private DBus session and native keyring. A short private temporary runtime directory avoids the Unix socket path-length limit. The environment had no configured managed credentials, runtime variables or outbound identities when execution started. Existing user host configuration, authentication and native collections were not loaded.

Actual Ironrun CLI creates the environment and stores a random test-only value through `env set --from-stdin --unsafe`. Actual Ironrun MCP waits for workspace trust. The test controller acts as the approver through actual `trust grant`, `access deny` and `trust revoke` commands. It observes only its own fixture's access metadata.

The child probe sends the synthetic value to a loopback HTTP endpoint in `X-Ironrun-Fixture`; the endpoint verifies a match and prints the same value. Ironrun returns `credential=[REDACTED]` and `HOST_LOOPBACK [REDACTED]` through the actual host. The next scripted provider request is checked for the redacted result and absence of the full synthetic value. These endpoints observe the instrumented path, not every background network connection or system call.

The provider is a deterministic local Anthropic-compatible SSE endpoint for Claude and an OpenAI-compatible chat-completions SSE endpoint for OpenCode. It dictates the tool arguments and final response. It does not test whether a real model chooses Ironrun appropriately or understands its security boundaries. Claude's discovered catalog contains twelve Ironrun tools. OpenCode exposes the fixture-allowed `ironrun_run_sealed` to its provider.

Claude explicitly allows the fixture's one `run_sealed` tool; OpenCode denies all other tool permissions and allows that one tool. These isolated settings let the integration exercise Ironrun's separate approval boundary. Default interactive host approval, host permission prompts and day-to-day onboarding remain unverified.

## Cancellation and lifecycle limits

The interruption signal targets the isolated host process group, including its MCP subprocess. This is not evidence of a host GUI cancellation button or MCP cancellation notification. No grant or probe HTTP request was observed before host exit. There was no independent child-start sentinel. Running-command cancellation, pending-request expiry, host reconnect/resume after process exit and revocation killing an already-running process were not tested here.

Claude catches SIGINT and may return process exit 0 while its structured completion reports `aborted_tools` or `aborted_streaming` with an interruption message. A zero process exit is therefore not counted as successful tool execution. The final cancellation predicate requires interruption evidence plus no grant, no HTTP call and no deadline timeout. OpenCode returned -2 for its observed SIGINT case. The retained earlier Claude cases preserve the incorrect fixture predicates rather than overwriting those results.

The 100 ms preapproval check is a finite regression observation, not a timing or authorization proof. Expiry checks test a grant's actual wall-clock expiry, with a new pending request denied to finish the host turn. They do not wait out the default 15-minute request expiry.

## Executable and source identities

The tested Ironrun diagnostic binary SHA256 is `809e6fe0ee5335ce26b09fb9153a28c74966a8789620d94167e1e20bc6e1c612`. It is the pre-existing native-Linux diagnostic build, not a signed or published release artifact. Its original source identity is retained unmodified under `provenance/original-runtime-source-identity.json`; build metadata is retained separately. All 182 recorded Go/module input hashes match fixed commit `829099e4bb46247dc7abd324f18e870b6eb2cd9f`. This comparison does not assign a later module-lock normalization or release artifact a test outcome it has not earned.

`provenance/executables.json` identifies the exact host, Ironrun, probe, Secret Service daemon and `secret-tool` binaries by size and SHA256. Host npm archives have verified registry integrity recorded in `provenance/tool-provenance.json`. Native Debian package provenance records the earlier archive/index signature and checksum verification. These are sampled file identities, not an OS image attestation.

Selected non-interruption cases ran `run_host_v4.py`; final Claude interruption ran `run_host_v6.py`. `case-inventory.json` maps every run to its exact preserved driver hash and retains raw-log size/hash inventories without publishing their contents. `drivers/` contains each historical driver. Versions 5 and 6 only refine the host-interruption result predicate after observing actual Claude behavior; they do not change Ironrun source.

## Retained setup and fixture failures

- OpenCode attempt 1 selected `/workspace` for its embedded session despite the process working directory. No provider or Ironrun execution occurred. Passing attempt 2 explicitly supplies documented `run --dir <fixture project>`. Original logs are represented by hashes, and the original failed summary is retained.
- Claude denial attempt 1 failed to start GNOME Keyring because its long control-socket path truncated to an existing directory. Native stderr/driver hashes remain in the inventory. The corrected driver uses a short private runtime directory. This is a fixture setup failure.
- Claude interruption attempt 1's predicate incorrectly required a nonzero exit, although Claude emitted a cancellation result and `aborted_streaming`. Attempt 2 required that exact cancellation result but instead observed host tool rejection and `aborted_tools`. Both original blocked/failed summaries remain. The final predicate checks either structured interruption form and the observed grant/HTTP-request conditions.

`provenance/cleanup.json` records no remaining matching fixture native daemons, MCP servers or drivers after all cases. Disposable encrypted test stores and raw capture files remain only in the private working area; they are not included in this selected package.

## Codex and Cursor

The prior actual Codex CLI 0.159.2 approve/resume capture is summarized under `prior-codex/`. It used an isolated synthetic native-store adapter with the real encrypted vault. It does not validate Linux Secret Service, and it was not rerun for this lifecycle matrix. Its original diagnostic binary identity and explicit host-approval configuration remain intact. No result is transferred between diagnostic binaries or native backends.

Cursor's official Linux 3.28.7 metadata was obtained, but the vendor's package endpoint returned HTTP 403 with Cloudflare error 1010, again on 2026-11-06 UTC. This environment also has no running GUI/authorized Cursor session. No Cursor host execution is claimed. The original and rechecked safe vendor response records omit cookies. No alternate download route or access-control bypass was attempted. Missing GTK/Xvfb observations are fixture prerequisites, not a claim that Cursor cannot run on Linux.

All Mac host pilots, real-model behavior, real external services, accessibility and human completion times remain outside these results. Those gates require separate evidence before a broad production-readiness claim.

## Replay

Use the exact hash-listed host binaries and diagnostic source/build, plus the native Debian tools identified in provenance. Adapt the absolute ROOT/NATIVE/IRONRUN/PROBE paths in a copied driver; keep that new driver separately identified. From the private fixture working area run:

```
python3 run_host_v6.py claude /absolute/fresh-output-dir approve
python3 run_host_v6.py opencode /absolute/another-fresh-output-dir deny
```

Supported scenarios are `approve`, `deny`, `expiry`, `revoke` and `cancel`. The output HOME must be new. The driver inherits managed proxy/TLS settings, uses no login or real provider key, creates disposable native stores, and enables only the isolated test tool permission. Do not replay against an existing host home or production vault. The archive intentionally excludes downloaded binaries and private state; replay requires obtaining the recorded public dependencies first.

`artifact-manifest.json` hashes files actually included and excludes itself. `package_selected.py` describes the selection allowlist. Raw captures must not be substituted for this compact selection when publishing evidence.
