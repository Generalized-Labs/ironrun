# Proposed public validation note — review before adding to the repository

Suggested destination: `docs/validation/linux-host-fixtures-20261106.md`, accompanied by the selected compact evidence and its SHA256 manifest. This file is an external draft only. No repository edit, publication, release or tag is performed by preparing it.

## Actual Linux hosts with a scripted provider

Claude Code 2.1.318 and OpenCode 1.19.5 were exercised on Linux amd64 against Ironrun's stdio MCP server and a disposable native GNOME Secret Service collection. Both passed approval/resume, denial, actual grant expiry and revocation checks. A bounded SIGINT test also interrupted a pending approval. No grant or probe HTTP request was observed before host exit; there was no independent child-start sentinel.

Each approval fixture used a random synthetic value and a local HTTP endpoint. Actual Ironrun CLI approval resumed the waiting host tool call; the endpoint received the matching value once. The actual host and its next scripted provider request received the redacted child output. The denial case made no HTTP request. After grant expiry or revocation, a second call returned to pending and was denied without a second HTTP request.

| Host | Approval/resume | Denial | Grant expiry | Revocation | Pending SIGINT |
|---|---|---|---|---|---|
| Claude Code 2.1.318 | Pass | Pass | Pass | Pass | Pass, bounded |
| OpenCode 1.19.5 | Pass | Pass | Pass | Pass | Pass, bounded |
| Codex CLI 0.159.2 | Earlier pass with native-store adapter | Not tested in this set | Not tested in this set | Not tested in this set | Not tested in this set |
| Cursor | Blocked before host execution | Not tested | Not tested | Not tested | Not tested |

The model endpoints were deterministic local fixtures; they specified tool arguments. Test controllers supplied approvals through actual CLI commands. These results do not measure real-model judgment, interactive host permission UX, Mac Keychain, running-command cancellation, or human daily use. SIGINT targeted the isolated process group; it does not establish GUI or MCP notification cancellation. Grant expiry was tested with a real one-second grant, not by editing persisted state. Pending-request expiry was not tested.

The fixture explicitly allowed one Ironrun tool at the host boundary. That setting is an isolated integration configuration, not a recommendation for global tool autoapproval. The full test archive retains setup failures and predicate corrections. Claude can exit 0 after SIGINT while its structured result reports an abort, so tool/result and observed grant/HTTP-request conditions—not exit status alone—determine the outcome.

The diagnostic Ironrun binary SHA256 is `809e6fe0ee5335ce26b09fb9153a28c74966a8789620d94167e1e20bc6e1c612`. All 182 recorded Go/module inputs match fixed commit `829099e4bb46247dc7abd324f18e870b6eb2cd9f`. This is not a signed release-artifact or final module-lock qualification. Host, probe and native-tool identities are recorded separately.

Cursor's official Linux 3.28.7 download endpoint returned HTTP 403/Cloudflare 1010 on the recheck. The fixture also lacks a running GUI/authorized Cursor session; no Cursor host outcome is inferred. The earlier Codex pass used a synthetic platform-store adapter and cannot acquire a native Secret Service claim from the other hosts' results.

Compact evidence includes case summaries, selected Ironrun call/result events, CLI approval/revocation output, driver and executable hashes, source comparison, failure inventory and a file manifest. It excludes raw built-in host instructions, complete provider requests, native keyring/vault files, caches, authentication state and binaries. Publication should link that compact package and preserve these limitations.
